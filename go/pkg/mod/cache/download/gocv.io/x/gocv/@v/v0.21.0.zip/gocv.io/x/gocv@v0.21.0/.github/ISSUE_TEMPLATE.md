<!--- Please provide a general summary of the issue in the Title above -->

## Description
<!--- Detailed information about the issue itself -->

## Steps to Reproduce
<!--- Provide a link to a live example, or an unambiguous set of steps to -->
<!--- reproduce this bug. Include code to reproduce, if relevant -->
1.
2.
3.
4.

## Your Environment
<!--- Include as many relevant details about your environment -->

* Operating System and version:
* OpenCV version used:
* How did you install OpenCV?
* GoCV version used:
* Go version:
* Did you run the `env.sh` or `env.cmd` script before trying to `go run` or `go build`?
