void LogSetOutputFunction(void *data);
