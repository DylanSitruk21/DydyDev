# Maintainers

Maintainership is on a per project basis.

### Core-maintainers
  - Derek Collison <derek@nats.io> [@derekcollison](https://github.com/derekcollison)