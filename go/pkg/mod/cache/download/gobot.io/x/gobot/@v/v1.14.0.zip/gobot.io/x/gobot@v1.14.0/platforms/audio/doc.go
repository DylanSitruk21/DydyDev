/*
Package audio provides the Gobot adaptor for audio.

For more information refer to the README:
https://github.com/hybridgroup/gobot/blob/master/platforms/audio/README.md
*/
package audio // import "gobot.io/x/gobot/platforms/audio"
