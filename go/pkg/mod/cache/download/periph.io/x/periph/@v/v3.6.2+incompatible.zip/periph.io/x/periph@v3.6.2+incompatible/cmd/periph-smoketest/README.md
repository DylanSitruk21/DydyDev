# periph-smoketest

This executable runs smoke tests, that is, tests that require hardware to
interact with and confirm that both the driver and the actual hardware work.
The executable exits with return code 0 when successful and non-zero when an
error is detected to enable automated testing lab.
