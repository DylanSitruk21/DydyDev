# Contributing

Thanks for contributing to the project! Please look at [the periph contribution
guidelines](https://periph.io/project/contributing/) first.
