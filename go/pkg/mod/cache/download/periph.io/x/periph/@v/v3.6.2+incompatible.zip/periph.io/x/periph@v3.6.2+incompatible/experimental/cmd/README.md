# experimental/cmd

You are welcome to send PR (pull request) to add experimental executables here.
Please follow the instructions in
[project/contributing/](https://periph.io/project/contributing/).
