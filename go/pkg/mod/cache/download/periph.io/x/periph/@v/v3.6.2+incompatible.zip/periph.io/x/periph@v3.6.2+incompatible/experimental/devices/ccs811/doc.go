// Copyright 2019 The Periph Authors. All rights reserved.
// Use of this source code is governed under the Apache License, Version 2.0
// that can be found in the LICENSE file.

// Package ccs811 controls CCS811 Volatile Organic Compounds sensor via
// I²C interface.
//
// Product page
//
// https://ams.com/ccs811
//
// Datasheet
//
// https://ams.com/documents/20143/36005/CCS811_DS000459_7-00.pdf
package ccs811
