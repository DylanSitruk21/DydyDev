// Copyright 2018 The Periph Authors. All rights reserved.
// Use of this source code is governed under the Apache License, Version 2.0
// that can be found in the LICENSE file.

// Package cmd contains tools.
//
// Visit https://github.com/google/periph/blob/master/cmd/README.md for more
// information about how to use the tools provided.
package cmd
