# ssd1306

Shows a bunny and exercise the code a bit.


## Bunny

- Bunny (U+1F407) is an emoji:
  - License: SIL Open Font License, Version 1.1  (OFL)
  - Source: Noto Sans: https://www.google.com/get/noto/


## Ballerine

- Original source:
  - License: Public domain
  - Source: https://commons.wikimedia.org/wiki/File:CF46618267_109996904033.gif
- Reprocessed animation:
  - Author: RetSamys
  - License: Creative Commons
  - Source: http://retsamys.deviantart.com/art/Ballerine-369619512
