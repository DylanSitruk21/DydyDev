# 'ssd1306' smoke test

Verifies that two SSD1306, one over I²C, one over SPI, can display the same
output.

It can also be leveraged to record the I/O to write playback unit tests. It is a
good example to reuse to write other device driver unit test.
